package newpackage;

public class Cancion {// Inicio de Clase
    // atributos
    private String titulo;
    private String artista;
    private String duracion;
    private boolean favorita;
    private boolean descarga;
            Artista artistista;
//metodos
    public Cancion() {
        this.titulo = "SIN ASIGNAR";
        this.artista = "SIN ASIGNAR";
        this.duracion = "-:-";
        this.favorita = false;
        this.descarga = false;
    }

    public Cancion(String titulo, String artista, String duracion, boolean favorita, boolean descarga) {
        this.titulo = titulo;
        this.artista = artista;
        this.duracion = duracion;
        this.favorita = favorita;
        this.descarga = descarga;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    public String getDuracion() {
        return duracion;
    }

    public boolean isFavorita() {
        return favorita;
    }

    public boolean isDescarga() {
        return descarga;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public void setArtista(String artista) {
        this.artista = artista;
    }

    public void setDuracion(String duracion) {
        this.duracion = duracion;
    }

    public void setFavorita(boolean favorita) {
        this.favorita = favorita;
    }

    public void setDescarga(boolean descarga) {
        this.descarga = descarga;
    }    

    public Artista getArtistista() {
        return artistista;
    }

    public void setArtistista(Artista artistista) {
        this.artistista = artistista;
    }
        
    void adelantar(){
        System.out.println("... primer metodo");
    }
    
    void imprimir(){
        System.out.println("Titulo = " + titulo);
        System.out.println("Artista = " + artista);
        System.out.println("Duracion = " + duracion);
    }
    
    public static void main(String[] args) {//inicio clase MAIN
        
        Cancion cancion2 =
        new Cancion("la bilirrubina", "nombre artista","4:1",true,true);
        cancion2.adelantar();
        
        System.out.println("titulo: "+ cancion2.titulo+
                            ", artista: "+ cancion2.artista+
                            ", duracion: "+ cancion2.duracion);
        
    }//fin clase MAIN
    

public String clasificacion() { // Inicio clasificacion
    String[] detalles = this.getDuracion().split(":");
    System.out.println(">>: " + detalles[0]);
    System.out.println(">>: " + detalles[1]);
    
    if (Integer.parseInt(detalles[0]) > 4) {
        return "LARGA";
    } else {
        return "CORTA";
    }
}

}//fin clasificacion
    
//}//fin de la clase
