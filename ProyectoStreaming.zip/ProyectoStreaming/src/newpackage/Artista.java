package newpackage;
public class Artista {
    //atributos
    private String nombre;
    private String apellidos;
    private int edad;
    private String fechaNacimiento;
    private String generoMusical;
  //metodos

    public Artista() {
    }

    public Artista(String nombre, String apellidos, int edad, String fechaNacimiento, String generoMusical) {
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.edad = edad;
        this.fechaNacimiento = fechaNacimiento;
        this.generoMusical = generoMusical;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public int getEdad() {
        return edad;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getGeneroMusical() {
        return generoMusical;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setGeneroMusical(String generoMusical) {
        this.generoMusical = generoMusical;
    }
//customer
    void mostrarDatos(){
        System.out.println("Nombre:\t\t " + getNombre());
        System.out.println("Edad:\t\t " + getEdad());
        System.out.println("Fecha de nacimiento: " + getFechaNacimiento());
        System.out.println("-----------------------------------");
    }
    void datos(){
        String[] detalles = this.getFechaNacimiento().split("-");
        System.out.println(">> :" + detalles[0]);
        System.out.println(">> :" + detalles[1]);
        System.out.println(">> :" + detalles[2]);
     
    
}
    
    
    
    
}
