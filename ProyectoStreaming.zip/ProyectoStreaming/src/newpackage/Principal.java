package newpackage;

public class Principal {// Inicio de Clase
    public static void main(String[] args) {// Inicio metodo main 
        //Escribe todo tu codigo aqui
        Cancion cancion1 = new Cancion();
        cancion1.adelantar();
        Cancion cancion2 = 
      new Cancion("La Bilirrubina", "Juan Luis Guerra", "4:00", true, true);
        cancion2.adelantar();
        Artista artista1 = new Artista();
      
        //artista1.cantar();
        artista1.setNombre("SHAKIRA");
        artista1.setEdad(10);
        artista1.setFechaNacimiento("25-05-1990");
        
        Artista artista2 = new Artista("CHAYANNE", "pereira", 30, "4-4-1993", "POP");
        
        System.out.println(artista1.getNombre());
        
        cancion2.imprimir();
        cancion2.setArtista("Juan");
        cancion2.imprimir();
        
        artista1.mostrarDatos();
        artista2.mostrarDatos();
        
        artista1.datos();
        System.out.println("=================================");
        cancion2.clasificacion();
    }// Fin metodo main
    
}
